import { useMemo } from "react";

const AllStatistics = ({ properties, views, bids, favourites }) => {
  const userData = JSON.parse(localStorage.getItem("user"));
  const userTypes = Array.isArray(userData?.userType)
    ? userData.userType
    : [userData?.userType]; // Handle multiple user types


  const getHoldAndCancelledPropertyData = (orderId) => {
    const filteredProperty =
      properties.filter((property) => property.orderId == orderId)?.[0] || {};
    const onHold = filteredProperty?.isonhold || false;
    const onCancel = filteredProperty?.isoncancel || false;
    return { onHold, onCancel };
  };

  const {
    allPropertiesCount,
    quotesProvidedCount,
    QuotesInProgressCount,
    QuotesCompletedCount,
    QuotesOnHoldCount,
    CancelledPropertiesCount,
    OnHoldPropertiesCount,
    PlanCount,
    PlanValidityCount,
    NoOfPropertiesCount,
    UsedPropertiesCount,
    totalNoOfProperties,
    quoteAccepted,
  } = useMemo(() => {
    let allPropertiesCount = 0;
    let quotesProvidedCount = 0;
    let QuotesInProgressCount = 0;
    let QuotesCompletedCount = 0;
    let QuotesOnHoldCount = 0;
    let CancelledPropertiesCount = 0;
    let OnHoldPropertiesCount = 0;
    let PlanCount = 0;
    let PlanValidityCount = 0;
    let NoOfPropertiesCount = 0;
    let UsedPropertiesCount = 0;
    let totalNoOfProperties = 0;
    let quoteAccepted = 0;

    bids.forEach((bid) => {
      if (bid.appraiserUserId == userData.userId) {
        const { onHold: propertyOnHold, onCancel: propertyOnCancel } =
          getHoldAndCancelledPropertyData(bid.orderId);
        allPropertiesCount += 1;
        quotesProvidedCount += bid.status <= 1 ? 1 : 0;
        QuotesInProgressCount += bid?.status == 0 ? 1 : 0;
        quoteAccepted += bid.status == 1 && bid?.orderStatus == null ? 1 : 0;
        QuotesCompletedCount +=
          bid?.status == 1 && bid?.orderstatus == 3 ? 1 : 0;
        QuotesOnHoldCount += bid?.orderstatus == 4 ? 1 : 0; //Quotes on hold by appraiser
        OnHoldPropertiesCount += propertyOnHold ? 1 : 0;
        CancelledPropertiesCount += propertyOnCancel ? 1 : 0;
      }
    });

    // Plan Data
    let currentPlanInfo = userData?.plans?.$values
      ? userData?.plans?.$values[0]
      : {};
    if (currentPlanInfo) {
      PlanCount = currentPlanInfo?.planName;
      NoOfPropertiesCount = currentPlanInfo?.noOfProperties;
      UsedPropertiesCount = userData?.usedProperties || 0;
      totalNoOfProperties = userData?.totalNoOfProperties || 0;
    }

    // Subscription End Date
    const userPlans = userData?.userSubscription?.$values
      ? userData?.userSubscription?.$values[0]
      : {};
    if (userPlans) {
      PlanValidityCount = userPlans?.endDate;
    }

    return {
      allPropertiesCount,
      quotesProvidedCount,
      QuotesInProgressCount,
      QuotesCompletedCount,
      QuotesOnHoldCount,
      CancelledPropertiesCount,
      OnHoldPropertiesCount,
      PlanCount,
      PlanValidityCount,
      NoOfPropertiesCount,
      UsedPropertiesCount,
      totalNoOfProperties,
      quoteAccepted,
    };
  }, [bids]);

  console.log({
    allPropertiesCount,
    quotesProvidedCount,
    QuotesInProgressCount,
    QuotesCompletedCount,
    QuotesOnHoldCount,
    CancelledPropertiesCount,
    OnHoldPropertiesCount,
    PlanCount,
    PlanValidityCount,
    NoOfPropertiesCount,
    UsedPropertiesCount,
    totalNoOfProperties,
    quoteAccepted,
  });

  const formatDate = (dateString) => {
    const options = {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour12: true,
    };
    return new Date(dateString).toLocaleString("en-US", options);
  };

  // Define statistics data
  const allStatistics = useMemo(() => {
    const stats = [
      {
        id: "allPropertiesCount",
        blockStyle: "stylecardnew1",
        icon: "fa fa-home",
        value: allPropertiesCount,
        name: "All Properties",
        visibleFor: [3, 5], // User type 1 & 6
      },
      {
        id: "quotesProvidedCount",
        blockStyle: "stylecardnew2",
        icon: "fa fa-file",
        value: quotesProvidedCount,
        name: "Quotes Provided",
        visibleFor: [3, 5], // Only user type 1
      },
      {
        id: "quoteAccepted",
        blockStyle: "stylecardnew3",
        icon: "fa fa-check",
        value: quoteAccepted,
        name: "Quotes Accepted",
        visibleFor: [3, 5],
      },
      {
        id: "QuotesInProgressCount",
        blockStyle: "stylecardnew4",
        icon: "fa fa-edit",
        value: QuotesInProgressCount,
        name: "Quotes in Progress",
        visibleFor: [3],
      },
      {
        id: "QuotesCompletedCount",
        blockStyle: "stylecardnew5",
        icon: "fa fa-check-circle",
        value: QuotesCompletedCount,
        name: "Quotes Completed",
        visibleFor: [3, 5],
      },
      {
        id: "QuotesOnHoldCount",
        blockStyle: "stylecardnew6",
        icon: "fa fa-pause",
        value: QuotesOnHoldCount,
        name: "Quotes On Hold by Appraiser",
        visibleFor: [3, 5],
      },
      {
        id: "CancelledPropertiesCount",
        blockStyle: "stylecardnew7",
        icon: "fa fa-times-circle",
        value: CancelledPropertiesCount,
        name: "Cancelled Properties",
        visibleFor: [3, 5],
      },
      {
        id: "OnHoldPropertiesCount",
        blockStyle: "stylecardnew8",
        icon: "fa fa-pause",
        value: OnHoldPropertiesCount,
        name: "On Hold Properties by Broker",
        visibleFor: [3, 5],
      },
      {
        id: "PlanCount",
        blockStyle: "stylecardnew9",
        icon: "fa fa-credit-card",
        value: PlanCount,
        name: "Plan",
        visibleFor: [3],
      },
      {
        id: "PlanValidityCount",
        blockStyle: "stylecardnew10",
        icon: "fa fa-hourglass-half",
        value: formatDate(PlanValidityCount),
        name: "Plan Validity",
        visibleFor: [3],
      },
      {
        id: "NoOfPropertiesCount",
        blockStyle: "stylecardnew11",
        icon: "fa fa-building",
        value: totalNoOfProperties,
        name: "No. of Properties",
        visibleFor: [3],
      },
      {
        id: "UsedPropertiesCount",
        blockStyle: "stylecardnew12",
        icon: "fa fa-home",
        value: UsedPropertiesCount,
        name: "Used Properties",
        visibleFor: [3],
      },
    ];

    return stats;
  }, [
    allPropertiesCount,
    quotesProvidedCount,
    QuotesInProgressCount,
    QuotesCompletedCount,
    QuotesOnHoldCount,
    CancelledPropertiesCount,
    OnHoldPropertiesCount,
    PlanCount,
    PlanValidityCount,
    NoOfPropertiesCount,
    UsedPropertiesCount,
    userTypes,
  ]);
  // Filter statistics based on user type
  const filteredStatistics = allStatistics.filter((stat) =>
    userTypes.some((type) => stat.visibleFor.includes(type))
  );

  return (
    <div className="statistics-container">
      {allStatistics.map((item) => (
        <div key={item.id} className={`ff_one ${item.blockStyle}`}>
          <div className="details">
            <div className="timer">{item.name}</div>
            <p>{item.value}</p>
          </div>
          <div className="icon">
            <i className={item.icon}></i>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AllStatistics;
